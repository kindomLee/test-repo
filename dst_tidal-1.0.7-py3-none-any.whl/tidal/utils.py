
from enum import Enum
from typing import List

import pandas as pd

from .exchange import Exchange


__all__ = [
    "BaseDesc", "OrderType", "Order", "Position", "Trade"
]


class BaseDesc:
    def __init__(self):
        self.name = None
        self.internal_name = None

    def __set_name__(self, owner, name):
        self.name = name
        self.internal_name = '_' + name

    def __get__(self, instance, instance_type):
        if instance is None:
            return self
        return getattr(instance, self.internal_name, None)

    def __set__(self, instance, value):
        setattr(instance, self.internal_name, value)


class OrderType(Enum):
    MARKET = 'Market'
    LIMIT = 'Limit'
    STOP = 'Stop'


class Order(object):
    def __init__(self, datetime: pd.Timestamp, instrument: str, quantity: int, price: float, order_type: OrderType, timelimit: pd.Timedelta,
                 trailing_price: float, derived_orders: list, valid: bool):
        self.datetime = datetime
        self.instrument = instrument
        self.quantity = quantity
        self.type = order_type
        self.price = price

        self.timelimit = timelimit

        self.trailing_price = trailing_price
        self.derived_orders = derived_orders

        self.valid = valid

    def __repr__(self):
        return f"Order {{DateTime:{self.datetime}, Instrument:{self.instrument}, Quantity:{self.quantity}, " \
               f"Type:{self.type.value}, Price:{self.price}, Deadline:{self.deadline}, Valid:{self.valid}, " \
               f"TrailingPrice:{self.trailing_price}, DerivedOrders:{self.derived_orders}}}"

    def __contains__(self, instrument: str):
        return instrument == self.instrument
    

class Position(object):
    def __init__(self, datetime: pd.Timestamp, instrument: str, quantity: int, price: float, commission: float, slip_cost: float, 
                 cost: float, pnl: float):
        self.datetime = datetime
        self.instrument = instrument
        self.quantity = quantity
        self.price = price
        self.commission = commission
        self.slip_cost = slip_cost
        self.cost = cost
        self.pnl = pnl

    def __repr__(self):
        return f"Position {{Datetime:{self.datetime}, Instrument:{self.instrument}, Quantity:{self.quantity}, " \
               f"Price:{self.price}, Commission:{self.commission}, Slip cost:{self.slip_cost}, Cost:{self.cost}, " \
               f"Pnl:{self.pnl}, Value:{self.value}}}"

    def __contains__(self, instrument: str):
        return instrument == self.instrument

    @property
    def value(self) -> float:
        return self.cost + self.pnl


class Trade(object):
    def __init__(self, instrument: str, open_datetime: pd.Timestamp, open_price: float, open_commission: float,
                 open_slip_cost: float, close_datetime: pd.Timestamp, close_price: float,
                 close_commission: float, close_slip_cost: float, close_type: OrderType, transaction_tax: float,
                 quantity: int):
        self.instrument = instrument
        self.open_datetime = open_datetime
        self.open_price = open_price
        self.open_commission = open_commission
        self.open_slip_cost = open_slip_cost
        self.close_datetime = close_datetime
        self.close_price = close_price
        self.close_commission = close_commission
        self.close_slip_cost = close_slip_cost
        self.close_type = close_type
        self.transaction_tax = transaction_tax
        self.quantity = quantity

    def __repr__(self):
        return f"Trade {{Instrument:{self.instrument}, Open {{Datetime:{self.open_datetime}, Price:{self.open_price}, " \
               f"Commission:{self.open_commission}, Slip cost:{self.open_slip_cost}}}, " \
               f"Close {{Datetime:{self.close_datetime}, Price:{self.close_price}, Commission:{self.close_commission}, " \
               f"Slip cost:{self.close_slip_cost}, Close type:{self.close_type.value}}}, " \
               f"Transaction tax:{self.transaction_tax}, Trade cost:{self.trade_cost}, Quantity:{self.quantity}, " \
               f"Position cost:{self.position_cost}, PnL:{self.pnl}}}"

    def __jsonencode__(self):
        return {
            "instrument": self.instrument, 
            "open": {
                "datetime": self.open_datetime.isoformat(),
                "price": self.open_price,
                "commission": self.open_commission,
                "slip_cost": self.open_slip_cost
            }, 
            "close": {
                "datetime": self.close_datetime.isoformat(),
                "price": self.close_price,
                "commission": self.close_commission,
                "slip_cost": self.close_slip_cost
            }, 
            "transaction_tax": self.transaction_tax,
            "trade_cost": self.trade_cost,
            "quantity": self.quantity,
            "position_cost": self.position_cost,
            "pnl": self.pnl
        }

    @property
    def trade_cost(self) -> float:
        return self.commission + self.transaction_tax

    @property
    def commission(self) -> float:
        return self.open_commission + self.close_commission

    @property
    def position_cost(self) -> float:
        return self.open_price * abs(self.quantity)

    @property
    def pnl(self) -> float:
        return (self.close_price - self.open_price) * self.quantity - self.trade_cost
