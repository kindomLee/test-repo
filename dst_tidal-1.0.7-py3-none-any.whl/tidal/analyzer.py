
import mplfinance as mpf

from enum import Enum
import pandas as pd
import plotly.graph_objs as go
from plotly.subplots import make_subplots

from .account import Account


__all__ = [
    "PlotType", "Analyzer"
]


class PlotType(Enum):
    LINE = go.Scatter
    BAR = go.Bar


class Analyzer(object):
    def __init__(self, account: Account, metrics: dict):
        self._account = account
        self._metrics = metrics

    def inst_chart_mpf(self, instrument: str, start_time: str = None, end_time: str = None):
        trades = self._account.hist_trades

        if instrument not in trades.keys():
            return

        quote_inst = self._account.exchange.quote_db(instrument)[start_time:end_time]

        buy_list = pd.Series(index=quote_inst.index, dtype='float64')
        sell_list = pd.Series(index=quote_inst.index, dtype='float64')

        pnl = 0

        for trade in trades[instrument]:
            if trade.open_datetime in quote_inst.index and trade.close_datetime in quote_inst.index:
                if trade.quantity > 0:
                    buy_list[trade.open_datetime] = trade.open_price
                    sell_list[trade.close_datetime] = trade.close_price
                else:
                    sell_list[trade.open_datetime] = trade.open_price
                    buy_list[trade.close_datetime] = trade.close_price
                pnl += trade.pnl

        apd = [mpf.make_addplot(buy_list,type='scatter', markersize=100, marker=6, color='green'),
               mpf.make_addplot(sell_list,type='scatter', markersize=100, marker=7, color='red')]

        title = '\n\n' + instrument + ', PnL: ' + str(round(pnl))
        mpf.plot(quote_inst, type='candle', volume=True, addplot=apd, title=title)

    def inst_chart(self, instrument: str, metric_name = '', plot_type = PlotType.LINE, scale = 1.0):
        if len(metric_name) > 0 and metric_name in self._metrics.keys():
            metric = self._metrics[metric_name].report
            metric = metric.loc[instrument] if 'instrument' in metric.index.names else metric
        else:
            metric = pd.DataFrame()

        quote_inst = self._account.exchange.quote_db(instrument)

        width = 1000 * scale

        chart_h = 600 * scale
        metric_h = 70 * scale
        arrow_size = 15 * scale
        spacing_h = metric_h * 0.5

        height = chart_h + 2 * metric_h + spacing_h + (metric_h + spacing_h) * len(metric.columns)
        spacing_h = spacing_h / height
        font_size = 12 * scale

        # Plot trades

        buy_win = pd.Series(index=quote_inst.index, dtype='float64')
        buy_lose = pd.Series(index=quote_inst.index, dtype='float64')
        sell_win = pd.Series(index=quote_inst.index, dtype='float64')
        sell_lose = pd.Series(index=quote_inst.index, dtype='float64')

        win_trades = self._account.win_trades
        lose_trades = self._account.lose_trades

        win_pnl, lose_pnl = 0., 0.
        line_shapes = []

        for trade in win_trades[instrument]:
            if trade.open_datetime in quote_inst.index and trade.close_datetime in quote_inst.index:
                if trade.quantity > 0:
                    buy_win[trade.open_datetime] = trade.open_price
                    sell_win[trade.close_datetime] = trade.close_price
                else:
                    sell_win[trade.open_datetime] = trade.open_price
                    buy_win[trade.close_datetime] = trade.close_price
                win_pnl += trade.pnl
                line_shapes.append(dict(type='line', x0=trade.open_datetime, y0=trade.open_price,
                                        x1=trade.close_datetime, y1=trade.close_price,
                                        line=dict(color='grey', width=2)))

        for trade in lose_trades[instrument]:
            if trade.open_datetime in quote_inst.index and trade.close_datetime in quote_inst.index:
                if trade.quantity > 0:
                    buy_lose[trade.open_datetime] = trade.open_price
                    sell_lose[trade.close_datetime] = trade.close_price
                else:
                    sell_lose[trade.open_datetime] = trade.open_price
                    buy_lose[trade.close_datetime] = trade.close_price
                lose_pnl += trade.pnl
                line_shapes.append(dict(type='line', x0=trade.open_datetime, y0=trade.open_price,
                                        x1=trade.close_datetime, y1=trade.close_price,
                                        line=dict(color='grey', width=2)))

        title = metric_name if len(metric_name) > 0 else instrument
        layout = dict(
            title=dict(text=title, x=0.5),
            width=width, height=height, shapes=line_shapes,
            font=dict(size=font_size),
            xaxis=dict(
                rangeselector=dict(
                    buttons=list([
                        dict(count=360, label='6H', step='minute', stepmode='backward'),
                        dict(count=720, label='12H', step='minute', stepmode='backward'),
                        dict(count=1, label='1D', step='day', stepmode='backward'),
                        dict(count=3, label='3D', step='day', stepmode='backward'),
                        dict(count=7, label='1W', step='day', stepmode='backward'),
                        dict(count=1, label='1M', step='month', stepmode='backward'),
                        dict(count=3, label='3M', step='month', stepmode='backward'),
                        dict(count=6, label='6M', step='month', stepmode='backward'),
                        dict(count=1, label='1Y', step='year', stepmode='backward'),
                        dict(step='all')
                    ])
                ),
                rangeslider=dict(
                    visible=True,
                    thickness=metric_h / height * 0.3
                ),
                type='date',
            )
        )

        hover_df = pd.concat([quote_inst[['volume']], metric], axis=1)
        for col in hover_df.columns:
            hover_df[col] = hover_df[col].apply(lambda x: col + ':@' + str(x) + '<br>')
        hovertext = hover_df.to_string(index=False, header=False, justify='right').replace(' ', '').replace('@', ' ').split('\n')

        chart = go.Candlestick(x=quote_inst.index, open=quote_inst["open"], high=quote_inst["high"],
                               low=quote_inst["low"], close=quote_inst["close"], name=instrument,
                               increasing_line_color='rgb(37, 152, 71)', decreasing_line_color='rgb(229, 33, 61)',
                               text=hovertext)
        buy_win = go.Scatter(x=quote_inst.index, y=buy_win, mode='markers', name='buy_win',
                             marker=go.scatter.Marker(size=arrow_size, symbol="arrow-up", color="green"))
        sell_win = go.Scatter(x=quote_inst.index, y=sell_win, mode='markers', name='sell_win',
                              marker=go.scatter.Marker(size=arrow_size, symbol="arrow-down", color="red"))
        buy_lose = go.Scatter(x=quote_inst.index, y=buy_lose, mode='markers', name='buy_lose',
                              marker=go.scatter.Marker(size=arrow_size, symbol="arrow-up", color="darkgreen"))
        sell_lose = go.Scatter(x=quote_inst.index, y=sell_lose, mode='markers', name='sell_lose',
                               marker=go.scatter.Marker(size=arrow_size, symbol="arrow-down", color="darkred"))
        volume = go.Bar(x=quote_inst.index, y=quote_inst['volume'], name='volume', showlegend=False, marker_color="steelblue")

        metric_num = len(metric.columns)
        metric_rows = 1 + metric_num
        chart_h = chart_h / height
        slider_h = metric_h * 0.5 / height
        metric_h = (1 - chart_h - slider_h) / metric_rows
        row_length = [metric_h for i in range(metric_num)] + [metric_h, slider_h, chart_h]

        win_rate = round(len(win_trades[instrument]) * 100 / (len(win_trades[instrument]) + len(lose_trades[instrument])), 2)
        chart_title = instrument + '     Win PnL: ' + str(round(win_pnl)) + '     Lose PnL: ' + str(round(lose_pnl)) + \
                      '     Total PnL: ' + str(round(win_pnl + lose_pnl)) + '     Win Rate: ' + str(win_rate)

        subplot_titles = [chart_title, '', 'volume'] + metric.columns.to_list()
        total_rows = metric_rows + 2
        fig = make_subplots(rows=total_rows, cols=1, row_width=row_length, vertical_spacing=spacing_h,
                            subplot_titles=subplot_titles,
                            figure=go.Figure(data=[chart, buy_win, sell_win, buy_lose, sell_lose], layout=layout))
        fig.update_annotations(font_size=font_size)

        fig.add_trace(volume, row=3, col=1)
        for i, m in enumerate(metric.columns):
            rows = i + 1 + 3
            fig.add_trace(plot_type.value(x=metric.index, y=metric[m], name=m), row=rows, col=1)
        fig.update_layout(hovermode="x unified")

        fig = go.FigureWidget(fig)

        def zoom(layout, xrange):
            quote_view = quote_inst.loc[fig.layout.xaxis.range[0]:fig.layout.xaxis.range[1]]
            metric_view = metric.loc[fig.layout.xaxis.range[0]:fig.layout.xaxis.range[1]]
            range_x = [fig.layout.xaxis.range[0], fig.layout.xaxis.range[1]]
            quote_border = (quote_view.high.max() - quote_view.low.min()) * 0.05

            metric_layout = {'xaxis3': dict(range=range_x),
                             'yaxis': dict(range=[quote_view.low.min() - quote_border, quote_view.high.max() + quote_border]),
                             'yaxis3': dict(range=[quote_view.volume.min(), quote_view.volume.max()])}
            metric_layout.update(
                {'xaxis' + str(i + 4): dict(range=range_x) for i, _ in enumerate(metric_view.columns)})
            metric_layout.update(
                {'yaxis' + str(i + 4): dict(range=[metric_view[col_name].min(), metric_view[col_name].max()])
                 for i, col_name in enumerate(metric_view.columns)})

            fig.update_layout(metric_layout)

        fig.layout.on_change(zoom, 'xaxis.range')

        return fig
