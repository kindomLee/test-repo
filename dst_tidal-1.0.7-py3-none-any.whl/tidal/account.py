
import copy
from typing import Dict, List, Union

import pandas as pd

from .utils import *
from .exchange import *
from .socket import *


__all__ = [
    "Account"
]


class Account(object):
    def __init__(self, socket: Union[SocketClient, None] = None):
        self._socket = socket

        self._update_init_cash: bool = True
        self._init_cash: float = 0

        self._update_cash: bool = True
        self._cash: float = 0

        self._update_inst_orders: bool = True
        self._inst_orders: Dict[str, List[Order]] = {}

        self._update_inst_positions: bool = True
        self._inst_positions: Dict[str, List[Position]] = {}

        self._update_win_trades: bool = True
        self._win_trades: Dict[str, List[Trade]] = {}

        self._update_lose_trades: bool = True
        self._lose_trades: Dict[str, List[Trade]] = {}

        self._update_hist_trades: bool = True
        self._hist_trades: Dict[str, List[Trade]] = {}

        self._update_win_num: bool = True
        self._win_num: int = 0

        self._update_lose_num: bool = True
        self._lose_num: int = 0

        self._update_trade_num: bool = True
        self._trade_num: int = 0

        self._update_position_cost: bool = True
        self._position_cost: float = 0

        self._update_trade_cost: bool = True
        self._trade_cost: float = 0

        self._update_slip_cost: bool = True
        self._slip_cost: float = 0

        self._update_turnover: bool = True
        self._turnover: float = 0

        self._update_pnl: bool = True
        self._pnl: float = 0

        self._update_value: bool = True
        self._value: float = 0

    @property
    def init_cash(self) -> float:
        if self._update_init_cash:
            self._init_cash = self._socket.prop("account", "init_cash")
            self._update_init_cash = False
        return self._init_cash

    @property
    def cash(self) -> float:
        if self._update_cash:
            self._cash = self._socket.prop("account", "cash")
            self._update_cash = False
        return self._cash

    @property
    def inst_orders(self) -> Dict[str, List[Order]]:
        if self._update_inst_orders:
            data = self._socket.prop("account", "inst_orders")
            self._inst_orders = { 
                inst: [
                    Order(datetime=pd.Timestamp(order.get("datetime")), instrument=order.get("instrument"),
                        quantity=order.get("quantity"), order_type=OrderType(order.get("type")), price=order.get("price"), 
                        timelimit=pd.Timedelta(order.get("timelimit")), trailing_price=order.get("trailing_price"),
                        derived_orders=[
                            Order(datetime=pd.Timestamp(derived_order.get("datetime")), instrument=derived_order.get("instrument"),
                                    quantity=derived_order.get("quantity"), order_type=OrderType(derived_order.get("type")), price=derived_order.get("price"), 
                                    timelimit=pd.Timedelta(derived_order.get("timelimit")), trailing_price=derived_order.get("trailing_price"),
                                    valid=derived_order.get("valid"))
                            for derived_order in order.get("derived_orders")
                        ],
                        valid=order.get("valid"))
                    for order in orders
                ]
                for inst, orders in data.items()
            }
            self._update_inst_orders = False
        return self._inst_orders

    @property
    def inst_positions(self) -> Dict[str, List[Position]]:
        if self._update_inst_positions:
            data = self._socket.prop("account", "inst_positions")
            self._inst_positions = { 
                inst: [
                    Position(datetime=pd.Timestamp(position.get("datetime")), instrument=position.get("instrument"),
                            quantity=position.get("quantity"), price=position.get("price"), commission=position.get("commission"),
                            slip_cost=position.get("slip_cost"), cost=position.get("cost"), pnl=position.get("pnl")) 
                    for position in positions
                ]
                for inst, positions in data.items()
            }
            self._update_inst_positions = False
        return self._inst_positions

    @property
    def win_trades(self) -> Dict[str, List[Trade]]:
        if self._update_win_trades:
            data = self._socket.prop("account", "win_trades")
            self._win_trades = { 
                inst: [
                    Trade(instrument=trade.get("instrument"), quantity=trade.get("quantity"),
                        open_datetime=pd.Timestamp(trade["open"].get("datetime")), open_price=trade["open"].get("price"), 
                        open_commission=trade["open"].get("commission"), open_slip_cost=trade["open"].get("slip_cost"),
                        close_datetime=pd.Timestamp(trade["close"].get("datetime")), close_price=trade["close"].get("price"), 
                        close_commission=trade["close"].get("commission"), close_slip_cost=trade["close"].get("slip_cost"),
                        close_type=OrderType(trade["close"].get("type")), transaction_tax=trade.get("transaction_tax")) 
                    for trade in trades
                ]
                for inst, trades in data.items()
            }
            self._update_win_trades = False
        return self._win_trades

    @property
    def lose_trades(self) -> Dict[str, List[Trade]]:
        if self._update_lose_trades:
            data = self._socket.prop("account", "lose_trades")
            self._lose_trades = { 
                inst: [
                    Trade(instrument=trade.get("instrument"), quantity=trade.get("quantity"),
                        open_datetime=pd.Timestamp(trade["open"].get("datetime")), open_price=trade["open"].get("price"), 
                        open_commission=trade["open"].get("commission"), open_slip_cost=trade["open"].get("slip_cost"),
                        close_datetime=pd.Timestamp(trade["close"].get("datetime")), close_price=trade["close"].get("price"), 
                        close_commission=trade["close"].get("commission"), close_slip_cost=trade["close"].get("slip_cost"),
                        close_type=OrderType(trade["close"].get("type")), transaction_tax=trade.get("transaction_tax")) 
                    for trade in trades
                ]
                for inst, trades in data.items()
            }
            self._update_lose_trades = False
        return self._lose_trades

    @property
    def hist_trades(self) -> Dict[str, List[Trade]]:
        if self._update_hist_trades:
            data = self._socket.prop("account", "hist_trades")
            self._hist_trades = { 
                inst: [
                    Trade(instrument=trade.get("instrument"), quantity=trade.get("quantity"),
                        open_datetime=pd.Timestamp(trade["open"].get("datetime")), open_price=trade["open"].get("price"), 
                        open_commission=trade["open"].get("commission"), open_slip_cost=trade["open"].get("slip_cost"),
                        close_datetime=pd.Timestamp(trade["close"].get("datetime")), close_price=trade["close"].get("price"), 
                        close_commission=trade["close"].get("commission"), close_slip_cost=trade["close"].get("slip_cost"),
                        close_type=OrderType(trade["close"].get("type")), transaction_tax=trade.get("transaction_tax")) 
                    for trade in trades
                ]
                for inst, trades in data.items()
            }
            self._update_hist_trades = False
        return self._hist_trades

    @property
    def win_num(self) -> int:
        if self._update_win_num:
            self._win_num = self._socket.prop("account", "win_num")
            self._update_win_num = False
        return self._win_num

    @property
    def lose_num(self) -> int:
        if self._update_lose_num:
            self._lose_num = self._socket.prop("account", "lose_num")
            self._update_lose_num = False
        return self._lose_num

    @property
    def trade_num(self) -> int:
        if self._update_trade_num:
            self._trade_num = self._socket.prop("account", "trade_num")
            self._update_trade_num = False
        return self._trade_num

    @property
    def exchange(self) -> Exchange:
        return self._exchange

    @property
    def position_cost(self) -> float:
        if self._update_position_cost:
            self._position_cost = self._socket.prop("account", "position_cost")
            self._update_position_cost = False
        return self._position_cost

    @property
    def trade_cost(self) -> float:
        if self._update_trade_cost:
            self._trade_cost = self._socket.prop("account", "trade_cost")
            self._update_trade_cost = False
        return self._trade_cost

    @property
    def slip_cost(self) -> float:
        if self._update_slip_cost:
            self._slip_cost = self._socket.prop("account", "slip_cost")
            self._update_slip_cost = False
        return self._slip_cost

    @property
    def turnover(self) -> float:
        if self._update_turnover:
            self._turnover = self._socket.prop("account", "turnover")
            self._update_turnover = False
        return self._turnover

    @property
    def pnl(self) -> float:
        if self._update_pnl:
            self._pnl = self._socket.prop("account", "pnl")
            self._update_pnl = False
        return self._pnl

    @property
    def value(self) -> float:
        if self._update_value:
            self._value = self._socket.prop("account", "value")
            self._update_value = False
        return self._value

    def reset(self) -> None:
        self._update_cash = True

        self._update_inst_orders = True
        self._update_inst_positions = True

        self._update_win_trades = True
        self._update_lose_trades = True
        self._update_hist_trades = True
        self._update_win_num = True
        self._update_lose_num = True
        self._update_trade_num = True

        self._update_position_cost = True
        self._update_trade_cost = True
        self._update_slip_cost = True
        self._update_turnover = True
        self._update_pnl = True
        self._update_value = True

        return self._socket.func("account", "reset")

    def link_exchange(self, exchange: Exchange) -> None:
        assert isinstance(exchange, Exchange)
        self._exchange = exchange

    def unlink_exchange(self) -> None:
        self._exchange = None

    def cancel_orders(self) -> None:
        self._update_inst_orders = True
        return self._socket.func("account", "cancel_orders")

    def liquidate_position(self) -> None:
        self._update_inst_orders = True
        return self._socket.func("account", "liquidate_position")

    def place_order(self, instrument: str, quantity: int, price: float, order_type: OrderType, take_profit: float = 0.,
                    stop_loss: float = 0., trailing_stop: bool = False, timelimit: pd.Timedelta = None) -> None:
        self._update_inst_orders = True
        return self._socket.func("account", "place_order", {
                "instrument": instrument, 
                "quantity": quantity,
                "price": price,
                "order_type": order_type.value,
                "take_profit": take_profit,
                "stop_loss": stop_loss,
                "trailing_stop": trailing_stop,
                "timelimit": timelimit
            }
        )

    def step(self) -> None:
        self._update_cash = True

        self._update_inst_orders = True
        self._update_inst_positions = True

        self._update_win_trades = True
        self._update_lose_trades = True
        self._update_hist_trades = True
        self._update_win_num = True
        self._update_lose_num = True
        self._update_trade_num = True

        self._update_position_cost = True
        self._update_trade_cost = True
        self._update_slip_cost = True
        self._update_turnover = True
        self._update_pnl = True
        self._update_value = True

        self._exchange._update_datetime = True
        self._exchange._update_valid = True

        return self._socket.func("account", "step")
