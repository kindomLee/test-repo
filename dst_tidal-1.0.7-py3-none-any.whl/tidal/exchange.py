from copy import deepcopy
from typing import Dict, List, Union
from enum import Enum

import pandas as pd

from .socket import SocketClient


__all__ = [
    "InstConfig", "StockConfig", "Exchange"
]


class ConfigDesc:
    def __init__(self):
        self.name = None
        self.internal_name = None

    def __set_name__(self, owner, name):
        self.name = name
        self.internal_name = '_' + name

    def __get__(self, instance, instance_type):
        if instance is None:
            return self
        return getattr(instance, self.internal_name, None)

    def __set__(self, instance, value):
        if value is not None:
            setattr(instance, self.internal_name, value)


class InstConfig(object):
    def __init__(self, margin: float, tick_size: float, tick_value: float, trade_unit: int,
                 commission: float, min_commission: float, transaction_tax: float):
        self.margin = margin
        self.tick_size = tick_size
        self.tick_value = tick_value
        self.trade_unit = trade_unit
        self.commission = commission
        self.min_commission = min_commission
        self.transaction_tax = transaction_tax

    @property
    def mult(self):
        return self.tick_value / self.tick_size

    def __repr__(self):
        return f"InstConfig {{Margin:{self.margin}, Tick Size:{self.tick_size}, Tick Value:{self.tick_value}, " \
               f"Trade Unit:{self.trade_unit}, Commission:{self.commission}, Min Commission:{self.min_commission}, " \
               f"Transaction Tax:{self.transaction_tax}}}"


class StockConfig(str, Enum):
    TW = 'TW'
    US = 'US'


class Exchange(object):
    def __init__(self, socket: Union[SocketClient, None] = None):
        self._socket = socket
        
        self._quote_names = ['open', 'high', 'low', 'close', 'volume']
        self._index_names = ['instrument', 'datetime']

        self._update_datetime: bool = True
        self._datetime: Union[pd.Timestamp, None] = None

        self._update_time_line: bool = True
        self._time_line: List[pd.Timestamp] = []

        self._update_additional_names: bool = True
        self._additional_names: List[str] = []

        self._update_valid: bool = True
        self._valid: bool = False

        self._update_inst_configs: bool = True
        self._inst_configs: Dict[str, InstConfig] = {}

        self._update_stock_config: bool = True
        self._stock_config: Union[InstConfig, None] = None

    def reset(self) -> None:
        self._socket.func("exchange", "reset")
            
    @property
    def datetime(self) -> pd.Timestamp:
        if self._update_datetime:
            self._datetime = self._socket.prop("exchange", "datetime")
            self._update_datetime = False
        return self._datetime

    @property
    def time_line(self) -> List[pd.Timestamp]:
        if self._update_time_line:
            self._time_line = self._socket.prop("exchange", "time_line")
            self._update_time_line = False
        return self._time_line

    @property
    def additional_names(self) -> List[str]:
        if self._update_additional_names:
            self._additional_names = self._socket.prop("exchange", "additional_names")
            self._update_additional_names = False
        return self._additional_names

    @property
    def valid(self) -> bool:
        if self._update_valid:
            self._valid = self._socket.prop("exchange", "valid")
            self._update_valid = False
        return self._valid

    def add_quote(self, quote: pd.DataFrame, append: bool = True) -> None:
        assert isinstance(quote, pd.DataFrame)
        assert all([col_name in quote.columns for col_name in self._quote_names])

        self._update_time_line = True
        self._update_additional_names = True

        return self._socket.func("exchange", "add_quote", {
            "quote": quote, "append": append
        })

    def quote(self, instrument: str = None, start_idx: int = 0, end_idx: int = 0) -> Union[pd.DataFrame, pd.Series]:
        return self._socket.func("exchange", "quote", { 
            "instrument": instrument, "start_idx": start_idx, "end_idx": end_idx 
        })

    def quote_db(self, instrument: str = None) -> pd.DataFrame:
        return self._socket.func("exchange", "quote_db", { "instrument": instrument })

    @property
    def inst_configs(self) -> Dict[str, InstConfig]:
        if self._update_inst_configs:
            data = self._socket.prop("exchange", "inst_configs")
            self._inst_configs = {
                inst: InstConfig(margin=config.get("margin"), tick_size=config.get("tick_size"), tick_value=config.get("tick_value"), 
                                trade_unit=config.get("trade_unit"), commission=config.get("commission"), min_commission=config.get("min_commission"), 
                                transaction_tax=config.get("transaction_tax"))
                for inst, config in data.items()
            }
            self._update_inst_configs = False
        return self._inst_configs

    def set_config(self, instrument: str, margin: float = None, tick_size: float = None, tick_value: float = None,
                   trade_unit: int = None, commission: float = None, min_commission: float = None, transaction_tax = None) -> None:
        self._update_inst_configs = True

        return self._socket.func("exchange", "set_config", {
            "instrument": instrument, "margin": margin, "tick_size": tick_size, "tick_value": tick_value,
            "trade_unit": trade_unit, "commission": commission, "min_commission": min_commission, "transaction_tax": transaction_tax
        })

    def get_config(self, instrument: str) -> InstConfig:
        inst_configs = self.inst_configs
        return inst_configs[instrument] if instrument in inst_configs.keys() else self.stock_config

    @property
    def stock_config(self) -> InstConfig:
        if self._update_stock_config:
            data = self._socket.prop("exchange", "stock_config")
            self._stock_config = InstConfig(margin=data.get("margin"), tick_size=data.get("tick_size"), tick_value=data.get("tick_value"), 
                                            trade_unit=data.get("trade_unit"), commission=data.get("commission"), min_commission=data.get("min_commission"),
                                            transaction_tax=data.get("transaction_tax"))
            self._update_stock_config = False
        return self._stock_config

    def set_stock_config(self, margin: float = None, tick_size: float = None, tick_value: float = None, trade_unit: int = None,
                         commission: float = None, min_commission: float = None, transaction_tax = None) -> None:
        self._update_stock_config = True
        
        return self._socket.func("exchange", "set_stock_config", {
            "margin": margin, "tick_size": tick_size, "tick_value": tick_value, "trade_unit": trade_unit,
            "commission": commission, "min_commission": min_commission, "transaction_tax": transaction_tax
        })

    def step(self) -> bool:
        self._update_datetime = True
        self._update_valid = True

        return self._socket.func("exchange", "step")
