
from collections import OrderedDict
import pandas as pd

from . import BaseMetric


__all__ = [
    "AccountInfo"
]


class AccountInfo(BaseMetric):
    def __init__(self):
        super().__init__()

    def reset(self):
        self._cash = OrderedDict()
        self._trade_cost = OrderedDict()
        self._position_cost = OrderedDict()
        self._slip_cost = OrderedDict()
        self._pnl = OrderedDict()
        self._value = OrderedDict()
        self._max_drawdown = OrderedDict()
        self._max_value = 0

    def evaluate(self):
        self._cash[self.datetime] = self.cash
        self._trade_cost[self.datetime] = self.trade_cost
        self._position_cost[self.datetime] = self.position_cost
        self._slip_cost[self.datetime] = self.slip_cost
        self._pnl[self.datetime] = self.pnl

        value = self.value
        self._value[self.datetime] = value

        self._max_value = value if value > self._max_value else self._max_value
        self._max_drawdown[self.datetime] = value / self._max_value - 1
