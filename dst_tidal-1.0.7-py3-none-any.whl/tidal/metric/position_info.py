
from collections import OrderedDict
import pandas as pd

from . import BaseMetric


__all__ = [
    "PositionInfo"
]


class PositionInfo(BaseMetric):
    def __init__(self):
        super().__init__()
        self._index_names = ['instrument', 'datetime']

    def reset(self):
        self._quantity = OrderedDict()
        self._price = OrderedDict()
        self._commission = OrderedDict()
        self._slip_cost = OrderedDict()
        self._pnl = OrderedDict()

    def evaluate(self):
        for inst, positions in self.inst_positions.items():
            quantity, price, commission, slip_cost, pnl = 0., 0., 0., 0., 0.

            for pos in positions:
                quantity += pos.quantity
                price += (pos.quantity * pos.price)
                commission += pos.commission
                slip_cost += pos.slip_cost
                pnl += pos.pnl

            self._quantity[(inst, self.datetime)] = quantity
            self._price[(inst, self.datetime)] = (price / quantity)
            self._commission[(inst, self.datetime)] = commission
            self._slip_cost[(inst, self.datetime)] = slip_cost
            self._pnl[(inst, self.datetime)] = pnl
