
from collections import OrderedDict
import pandas as pd

from . import BaseMetric
from .. import Account


__all__ = [
    "Portfolio"
]


class Portfolio(BaseMetric):
    def __init__(self, benchmark: pd.DataFrame):
        self._bench_init = 0
        super().__init__()

        self.set_benchmark(benchmark)

    def reset(self):
        self._cum_bench: dict = OrderedDict()
        self._cum_wo_cost: dict = OrderedDict()
        self._cum_w_cost: dict = OrderedDict()

        if isinstance(self.account, Account):
            self._value_old = self.value
            self._cost_old = self.trade_cost
        else:
            self._value_old = 0
            self._cost_old = 0

        self._bench_old = self._bench_init

    def set_benchmark(self, benchmark: pd.DataFrame):
        assert isinstance(benchmark, pd.DataFrame)
        assert all([idx_name in benchmark.index.names for idx_name in ['datetime']])

        self._benchmark = benchmark.sort_index()
        self._col_name = benchmark.columns[0]
        self._bench_init = self._benchmark.iloc[0][self._col_name]

    def evaluate(self):
        try:
            bench_now = self._benchmark.loc[self.account.exchange.datetime][self._col_name]
        except:
            bench_now = self._bench_old
        bench = (bench_now - self._bench_old) / self._bench_init

        cost_now = self.trade_cost + self.slip_cost
        cost = (cost_now - self._cost_old) / self.account.init_cash

        value_now = self.value + cost_now
        value = (value_now - self._value_old) / self.account.init_cash

        self._cum_bench[self.datetime] = bench + (self._cum_bench[next(reversed(self._cum_bench))]
                                                  if len(self._cum_bench) > 0 else 0)
        self._cum_wo_cost[self.datetime] = value + (self._cum_wo_cost[next(reversed(self._cum_wo_cost))]
                                                    if len(self._cum_wo_cost) > 0 else 0)
        self._cum_w_cost[self.datetime] = (value - cost) + (self._cum_w_cost[next(reversed(self._cum_w_cost))]
                                                            if len(self._cum_w_cost) > 0 else 0)

        self._cost_old = cost_now
        self._value_old = value_now
        self._bench_old = bench_now
