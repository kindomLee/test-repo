
import pandas as pd

from . import BaseMetric


__all__ = [
    "AdditionalInfo"
]


class AdditionalInfo(BaseMetric):
    def __init__(self):
        super().__init__()

    def reset(self):
        if self.account is not None:
            self._additional_info = self.account.exchange.additional_names

    def evaluate(self):
        pass

    @property
    def report(self) -> pd.DataFrame:
        return self.account.exchange.quote_db()[self._additional_info]
