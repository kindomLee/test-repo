
from collections import OrderedDict
import pandas as pd

from . import BaseMetric
from .. import Account


__all__ = [
    "QlibPortfolio"
]


class QlibPortfolio(BaseMetric):
    def __init__(self, benchmark: pd.DataFrame):
        self._bench_init = 0
        super().__init__()

        self.set_benchmark(benchmark)

    def reset(self):
        self._return: dict = OrderedDict()
        self._cost: dict = OrderedDict()
        self._bench: dict = OrderedDict()
        self._turnover: dict = OrderedDict()

        if isinstance(self.account, Account):
            self._value_old = self.value
            self._cost_old = self.trade_cost
        else:
            self._value_old = 0
            self._cost_old = 0

        self._bench_old = self._bench_init

    def set_benchmark(self, benchmark: pd.DataFrame):
        assert isinstance(benchmark, pd.DataFrame)
        assert all([idx_name in benchmark.index.names for idx_name in ['datetime']])

        self._benchmark = benchmark.sort_index()
        self._col_name = benchmark.columns[0]
        self._bench_init = self._benchmark.iloc[0][self._col_name]

    def evaluate(self):
        cost_now = self.trade_cost + self.slip_cost
        self._cost[self.datetime] = (cost_now - self._cost_old) / self.account.init_cash

        self._turnover[self.datetime] = self.account.turnover / self._value_old

        value_now = self.value + cost_now
        self._return[self.datetime] = (value_now - self._value_old) / self.account.init_cash

        try:
            bench_now = self._benchmark.loc[self.account.exchange.datetime][self._col_name]
        except:
            bench_now = self._bench_old
        self._bench[self.datetime] = (bench_now - self._bench_old) / self._bench_init

        self._cost_old = cost_now
        self._value_old = value_now
        self._bench_old = bench_now
