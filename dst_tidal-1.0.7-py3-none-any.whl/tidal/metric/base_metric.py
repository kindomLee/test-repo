
from abc import ABC, abstractmethod
from collections import OrderedDict
import pandas as pd
from typing import Dict, List

from ..account import Account
from ..utils import BaseDesc, Trade, Position


__all__ = [
    "BaseMetric"
]


class AccountDesc(BaseDesc):
    def __init__(self):
        super().__init__()

    def __set__(self, instance, value):
        assert isinstance(value, Account)
        if value is not None:
            setattr(instance, self.internal_name, value)


class BaseMetric(ABC):
    account: Account = AccountDesc()

    def __init__(self):
        self._name = type(self).__name__
        self._index_names = ["datetime"]

        self._update_report = False
        self._report = None

        self.reset()

    @property
    def name(self) -> str:
        return self._name

    @property
    def datetime(self) -> pd.Timestamp:
        return self.account.exchange.datetime

    @property
    def init_cash(self) -> float:
        return self.account.init_cash

    @property
    def cash(self) -> float:
        return self.account.cash

    @property
    def trade_cost(self) -> float:
        return  self.account.trade_cost

    @property
    def position_cost(self) -> float:
        return self.account.position_cost

    @property
    def slip_cost(self) -> float:
        return self.account.slip_cost

    @property
    def turn_over(self) -> float:
        return self.account.turn_over

    @property
    def pnl(self) -> float:
        return self.account.pnl

    @property
    def value(self) -> float:
        return self.account.value

    @property
    def inst_positions(self) -> Dict[str, List[Position]]:
        return self.account.inst_positions

    @property
    def win_trades(self) -> Dict[str, List[Trade]]:
        return self.account.win_trades

    @property
    def lose_trades(self) -> Dict[str, List[Trade]]:
        return self.account.lose_trades

    @property
    def hist_trades(self) -> Dict[str, List[Trade]]:
        return self.account.hist_trades

    @property
    def win_num(self) -> int:
        return self.account.win_num

    @property
    def lose_num(self) -> int:
        return self.account.lose_num

    @property
    def trade_num(self) -> int:
        return self.account.trade_num

    def _reset(self) -> None:
        assert isinstance(self.account, Account)
        self._update_report = True
        self.reset()

    @abstractmethod
    def reset(self) -> None:
        raise NotImplementedError

    def _evaluate(self) -> None:
        assert isinstance(self.account, Account)
        self._update_report = True
        self.evaluate()

    @abstractmethod
    def evaluate(self) -> None:
        raise NotImplementedError

    @property
    def report(self) -> pd.DataFrame:
        if self._update_report:
            self._report = pd.DataFrame()

            for name, metric in self.__dict__.items():
                if isinstance(metric, OrderedDict):
                    name = name[2:] if name[0:2] == '__' else (name[1:] if name[0:1] == '_' else name)
                    self._report[name] = pd.Series(metric)

            self._report.index.names = self._index_names
            self._update_report = False
            self._report = self._report.sort_index()

        return self._report

    @property
    def instance(self):
        try:
            return {(name[2:] if name[0:2] == '__' else (name[1:] if name[0:1] == '_' else name)): metric[next(reversed(metric))]
                    for name, metric in self.__dict__.items() if isinstance(metric, OrderedDict)}
        except:
            return None
