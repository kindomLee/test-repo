import json, logging, pickle

from typing import Callable, Dict, TypedDict, Union
from threading import Thread

import zmq
from zmq.utils.monitor import recv_monitor_message


__all__ = [
    "SocketClient"
]


class SocketClient(object):
    def __init__(self, addr: str) -> None:
        self._socket: zmq.Socket = zmq.Context().socket(zmq.REQ)
        self._context = self._socket.connect(addr)
        
        self._connected: bool = False

        self._monitor: zmq.Socket = self._socket.get_monitor_socket()
        self._monitor_thread = Thread(target=self._event_monitor, daemon=True)
        self._monitor_thread.start()

        self._hand_shake()

        while not self._connected:
            continue

    def __enter__(self):
        return self
    
    def __del__(self):
        self.close()

    def __exit__(self, *args, **kwargs):
        self.__del__()

    def close(self):
        self._monitor.close()
        self._socket.close()

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def closed(self) -> bool:
        return self._socket.closed

    def _event_monitor(self):
        while self._monitor.poll():
            monitor_msg = recv_monitor_message(self._monitor)
            event = monitor_msg["event"]

            if event == zmq.EVENT_HANDSHAKE_SUCCEEDED:
                self._connected = True
                
            elif event == zmq.EVENT_DISCONNECTED:
                break

            logging.debug(f"{__class__.__name__} {self._context.addr}: Event {zmq.Event(event).name}")

        self._monitor.close()
        self._socket.close()

    def _hand_shake(self):
        self._socket.send(b"")
        self._socket.recv()

        while not self._connected:
            continue

    def response_wrapper(func: Callable) -> Callable:
        def response_handler(self, *args, **kwargs) -> None:
            try:
                if not self._connected:
                    raise Exception(f"{__class__.__name__} {self._context.addr}: No Server Connection ERROR! ")
                
                response = func(self, *args, **kwargs)

                response_type = response[:1].decode()
                response_data = response[1:]

                if len(response_data) == 0:
                    return None
                
                elif response_type == "0":
                    return json.loads(response_data)
                
                elif response_type == "1":
                    data = pickle.loads(response_data)
                    if isinstance(data, dict) and "error" in data.keys():
                        raise Exception(data["error"])
                    else:
                        return data
                    
                else:
                    return response
                
            except Exception as e:
                logging.error(f"{__class__.__name__} {self._context.addr}: {e}")
                return None

        return response_handler
    
    @response_wrapper
    def prop(self, module: str, prop: str):
        self._socket.send_pyobj({ "mode": "prop", "module": module, "prop": prop })
        return self._socket.recv()

    @response_wrapper
    def func(self, module: str, func: str, params: Dict[str, any] = None) -> Union[Dict, str]:
        self._socket.send_pyobj({ "mode": "func", "module": module, "func": func, "params": params })
        return self._socket.recv()
