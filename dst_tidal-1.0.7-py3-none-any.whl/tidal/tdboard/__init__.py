from __future__ import annotations
import logging
from typing import Union, TYPE_CHECKING

from flask import Flask
from flask_cors import CORS

from . import routes
from .api import routes as api_routes
from .api.quote import routes as quote_routes
from .api.metric import routes as metric_routes
from .api.trade import routes as trade_routes


if TYPE_CHECKING:
    from .. import Tidal


__all__ = [
    "create_app", "tidal"
]


tidal: Union[Tidal, None] = None


def create_app(_tidal: Tidal) -> Flask:
    global tidal
    tidal = _tidal

    app = Flask(__name__, static_folder=None)

    CORS(app)
    
    app.register_blueprint(routes.tdboard_blueprint)
    app.register_blueprint(api_routes.api_blueprint)
    app.register_blueprint(quote_routes.quote_blueprint)
    app.register_blueprint(metric_routes.metric_blueprint)
    app.register_blueprint(trade_routes.trade_blueprint)

    log = logging.getLogger('werkzeug')
    log.setLevel(logging.INFO)

    return app
