import os
from flask import Blueprint, send_from_directory


tdboard_blueprint = Blueprint('tdboard', __name__, static_folder="ui")


@tdboard_blueprint.route("/", defaults={"path": ""})
@tdboard_blueprint.route("/<path:path>")
def serve(path):
    if path != "" and os.path.exists(tdboard_blueprint.static_folder + '/' + path):
        return send_from_directory(tdboard_blueprint.static_folder, path)
    else:
        return send_from_directory(tdboard_blueprint.static_folder, 'index.html')
    