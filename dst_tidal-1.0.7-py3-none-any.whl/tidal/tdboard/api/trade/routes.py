import json

from typing import Dict, List

from flask import Blueprint, request
from flask_restx import Api, Resource, fields


trade_blueprint = Blueprint("trade", __name__, url_prefix="/api/trade")


api = Api(
    trade_blueprint,
    version="0.0.1",
    title="Trade",
    description="Trade API",
    doc="doc"
)


ns = api.namespace(name="", description="Trade API")


@ns.route("/trade_report")
@ns.doc(
    params={},
)
class TradeReport(Resource):
    @ns.doc(responses={
        200: 'Success',
        400: 'Validation Error'
    })
    def get(self):
        from ... import tidal
        trade_report = tidal.trade_report.reset_index()
        return {
            "columns": trade_report.columns.to_list(),
            "data": trade_report.to_json(orient='records', date_format='iso')
        }

class AdvancedJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if hasattr(obj, '__jsonencode__'):
            return obj.__jsonencode__()

        if isinstance(obj, set):
            return list(obj)
        return json.JSONEncoder.default(self, obj)

@ns.route("/trade_insts")
@ns.doc(
    params={},
)
class TradeInsts(Resource):
    trade_model = api.model(
        "trade_model",
        {
            "instruments": fields.List(
                fields.String, 
                required=True, 
                example=[""]
            )
        }
    )

    @ns.doc(responses={
        200: 'Success',
        400: 'Validation Error'
    })
    @ns.expect(trade_model, validate=False)
    def post(self):
        from ... import tidal
        params = request.get_json()

        trade_reports: Dict[str: List[List]] = {}
        
        for instrument in params["instruments"]:
            trade_reports[instrument] = json.dumps(tidal._account.hist_trades[instrument], cls=AdvancedJSONEncoder)
        
        return trade_reports
        