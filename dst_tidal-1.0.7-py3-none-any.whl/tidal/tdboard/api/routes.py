from flask import Blueprint
from flask_restx import Api, Resource


api_blueprint = Blueprint("api", __name__, url_prefix="/api")


api = Api(
    api_blueprint,
    version="0.0.1",
    title="TidalBoard",
    description="API",
    doc="doc"
)


ns = api.namespace(name="", description="Tidal API")


@ns.route("/")
@ns.doc(
    params={},
)
class TidalAPI(Resource):
    @ns.doc(responses={
        200: 'Success',
        400: 'Validation Error'
    })
    def get(self):
        return "Tidal API"
    