from typing import Dict, List

from flask import Blueprint, request
from flask_restx import Api, Resource, fields


quote_blueprint = Blueprint("quote", __name__, url_prefix="/api/quote")


api = Api(
    quote_blueprint,
    version="0.0.1",
    title="Quote",
    description="Quote API",
    doc="doc"
)


ns = api.namespace(name="", description="Quote API")


@ns.route("/inst_list")
@ns.doc(
    params={},
)
class InstList(Resource):
    @ns.doc(responses={
        200: 'Success',
        400: 'Validation Error'
    })
    def get(self):
        from ... import tidal
        return tidal.exchange.quote_db().index.get_level_values("instrument").unique().to_list()
    

@ns.route("/inst_charts")
@ns.doc(
    params={},
)
class InstCharts(Resource):
    chart_model = api.model(
        "chart_model",
        {
            "instruments": fields.List(
                fields.String, 
                required=True, 
                example=[""]
            )
        }
    )

    @ns.doc(responses={
        200: 'Success',
        400: 'Validation Error'
    })
    @ns.expect(chart_model, validate=False)
    def post(self):
        from ... import tidal
        params = request.get_json()

        charts: Dict[str: List[List]] = {}

        for instrument in params["instruments"]:
            chart = tidal.exchange.quote_db(instrument).reset_index()
            charts[instrument] = chart.to_json(orient='records', date_format='iso')

        return charts
