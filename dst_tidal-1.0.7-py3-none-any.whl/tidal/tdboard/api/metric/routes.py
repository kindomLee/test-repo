from typing import Dict, List

from flask import Blueprint, request
from flask_restx import Api, Resource, fields


metric_blueprint = Blueprint("metric", __name__, url_prefix="/api/metric")


api = Api(
    metric_blueprint,
    version="0.0.1",
    title="Metric",
    description="Metric API",
    doc="doc"
)


ns = api.namespace(name="", description="Metric API")


@ns.route("/metric_list")
@ns.doc(
    params={},
)
class MetricList(Resource):
    @ns.doc(responses={
        200: 'Success',
        400: 'Validation Error'
    })
    def get(self):
        from ... import tidal
        return list(tidal.metrics.keys())
    

@ns.route("/metric_reports")
@ns.doc(
    params={},
)
class GetMetrics(Resource):
    metric_model = api.model(
        "metric_model",
        {
            "metrics": fields.List(
                fields.String, 
                required=True, 
                example=[""]
            )
        }
    )

    @ns.doc(responses={
        200: 'Success',
        400: 'Validation Error'
    })
    @ns.expect(metric_model, validate=False)
    def post(self):
        from ... import tidal
        params = request.get_json()

        metrics: Dict[str: List[List]] = {}

        for name in params["metrics"]:
            metric = tidal.metrics[name].report.reset_index()
            metrics[name] = {
                "columns": metric.columns.to_list(),
                "data": metric.to_json(orient='values', date_format='iso')
            }

        return metrics