
from abc import ABC, abstractmethod
import pandas as pd
from typing import Union, Dict, List

from ..account import Account
from ..exchange import Exchange
from ..utils import OrderType, BaseDesc, Order, Position


__all__ = [
    "BaseStrategy"
]


class AccountDesc(BaseDesc):
    def __init__(self):
        super().__init__()

    def __set__(self, instance, value):
        assert isinstance(value, Account)
        if value is not None:
            setattr(instance, self.internal_name, value)


class ExchangeDesc(BaseDesc):
    def __init__(self):
        super().__init__()

    def __set__(self, instance, value):
        assert isinstance(value, Exchange)
        if value is not None:
            setattr(instance, self.internal_name, value)


class BaseStrategy(ABC):
    account: Account = AccountDesc()
    exchange: Exchange = ExchangeDesc()

    def __init__(self):
        pass

    @property
    def datetime(self) -> pd.Timestamp:
        return self.exchange.datetime

    @property
    def init_cash(self) -> float:
        return self.account.init_cash

    @property
    def cash(self) -> float:
        return self.account.cash

    @property
    def position_cost(self) -> float:
        return self.account.position_cost

    @property
    def pnl(self) -> float:
        return self.account.pnl

    @property
    def value(self) -> float:
        return self.account.value

    @property
    def inst_orders(self) -> Dict[str, List[Order]]:
        return self.account.inst_orders

    @property
    def inst_positions(self) -> Dict[str, List[Position]]:
        return self.account.inst_positions

    def quote(self, instrument: str = None, start_idx = 0, end_idx = 0) -> Union[pd.DataFrame, dict]:
        return self.exchange.quote(instrument, start_idx, end_idx)

    def place_order(self, instrument: str, quantity: int, price: float, order_type: OrderType, take_profit: float = 0.,
                    stop_loss: float = 0., trailing_stop: bool = False, timelimit: pd.Timedelta = None) -> bool:
        return self.account.place_order(instrument, quantity, price, order_type, take_profit, stop_loss, trailing_stop, timelimit)

    def cancel_orders(self) -> None:
        self.account.cancel_orders()

    def liquidate_position(self) -> None:
        self.account.liquidate_position()

    def _on_init(self) -> None:
        assert isinstance(self.account, Account)
        quote_db = self.on_init(self.account.exchange.quote_db())
        self.exchange.add_quote(quote_db, append=False)

    def _on_trade(self) -> None:
        assert isinstance(self.account, Account)
        self.on_trade()

    def on_init(self, quote_db: pd.DataFrame) -> pd.DataFrame:
        return quote_db

    @abstractmethod
    def on_trade(self) -> None:
        raise NotImplementedError
