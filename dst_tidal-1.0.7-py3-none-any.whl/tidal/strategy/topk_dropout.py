
import pandas as pd

from . import BaseStrategy


__all__ = [
    "TopkDropout"
]


class TopkDropout(BaseStrategy):
    def __init__(self, topk: int = 50, ndrop: int = 5, feature_name: str = 'score', risk_degree: float = 0.95,
                 timelimit: pd.Timedelta = pd.Timedelta(1, 'd')):
        super().__init__()
        self._topk = topk
        self._ndrop = ndrop
        self._risk_degree = risk_degree
        self._feature_name = feature_name
        self._timelimit = timelimit

    def on_trade(self) -> None:
        from .. import OrderType

        cash = self.cash
        quote = self.quote()
        
        pos_quote = quote.loc[quote.index.isin(self.inst_positions.keys())]
        other_quote = quote.loc[~quote.index.isin(list(self.inst_orders.keys()) + list(self.inst_positions.keys()))]
        other_quote = other_quote.sort_values(by=self._feature_name, ascending=False).iloc[:self._topk + self._ndrop - len(pos_quote)]
        trade_quote = pd.concat([other_quote, pos_quote]).sort_values(by=self._feature_name, ascending=False)

        sell_list = pos_quote.iloc[pos_quote.index.isin(
            trade_quote.iloc[-self._ndrop:].index)]

        for inst, positions in self.inst_positions.items():
            if inst in sell_list.index:
                quantity = -sum(pos.quantity for pos in positions)
                price = self.quote(inst)['close']
                value = sum(pos.value for pos in positions)

                self.place_order(inst, quantity, price, OrderType.MARKET, timelimit=self._timelimit)
                cash = cash + value

        buy_list = other_quote.iloc[: len(sell_list) + self._topk - len(self.inst_positions)].index
        value = cash * self._risk_degree / len(buy_list) if len(buy_list) > 0 else 0

        for inst in buy_list:
            price = self.quote(inst)['close']
            quantity = value / price
            self.place_order(inst, quantity, price, OrderType.MARKET, timelimit=self._timelimit)
