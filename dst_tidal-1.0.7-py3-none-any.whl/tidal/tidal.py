import requests, logging

from enum import Enum
from typing import Callable, Dict, Union

import pandas as pd
from tqdm import tqdm

from .socket import *
from .account import *
from .exchange import *
from .strategy import BaseStrategy
from .metric import BaseMetric
from .analyzer import Analyzer
from .tdboard import create_app


__all__ = [
    "Tidal"
]


class State(Enum):
    IDLE = 'Idle'
    INIT = 'Initializing'
    BACKTEST = 'Backtesting'


class Tidal(object):
    TIDALSERVICE_ADDR = "tidal.dst.cathayholdings.internal.com.tw"

    def __init__(self, init_cash: float, slip_ticks: float = 1., stock_config: StockConfig = StockConfig.TW, load_configs: bool = True):
        try:
            port: int = requests.get(f'http://{self.TIDALSERVICE_ADDR}/accessTidalRequest', timeout=5).json()
            self._socket: SocketClient = SocketClient(f"tcp://{self.TIDALSERVICE_ADDR}:{port}")
            
            self._socket.func("self", "init", {
                    "init_cash": init_cash,
                    "slip_ticks": slip_ticks,
                    "stock_config": stock_config.value,
                    "load_configs": load_configs
                }
            )

            self._exchange = Exchange(socket=self._socket)

            self._account = Account(socket=self._socket)
            self._account.link_exchange(self._exchange)

            self._metrics: Dict[str, BaseMetric] = {}
            self._strategy = None

            self._analyzer = Analyzer(self.account, self._metrics)
            self._state = State.IDLE

            self._update_trade_report: bool = True
            self._trade_report: Union[pd.DataFrame, None] = None

        except Exception as e:
            logging.error(e)
        
    def __enter__(self):
        return self
    
    def __del__(self):
        self.close()

    def __exit__(self, *args, **kwargs):
        self.__del__()

    def close(self):
        self._socket.close()

    @property
    def state(self):
        return self._state

    @property
    def exchange(self) -> Exchange:
        return self._exchange

    @property
    def account(self) -> Account:
        return self._account

    @property
    def analyzer(self) -> Analyzer:
        return self._analyzer

    @property
    def win_trades(self) -> dict:
        return self._account.win_trades

    @property
    def lose_trades(self) -> dict:
        return self._account.lose_trades

    @property
    def hist_trades(self) -> dict:
        return self._account.hist_trades

    @property
    def trade_report(self) -> pd.DataFrame:
        if self._update_trade_report:
            self._trade_report = self._socket.prop("self", "trade_report")
            self._update_trade_report = False
        return self._trade_report

    @property
    def metrics(self) -> Dict[str, BaseMetric]:
        return self._metrics

    def add_quote(self, quote: pd.DataFrame) -> None:
        assert isinstance(quote, pd.DataFrame)
        self._account.exchange.add_quote(quote)

    def set_strategy(self, strategy: BaseStrategy) -> None:
        assert isinstance(strategy, BaseStrategy)
        self._strategy = strategy
        self._strategy.account = self._account
        self._strategy.exchange = self._exchange

    def add_metric(self, metric: BaseMetric) -> None:
        assert isinstance(metric, BaseMetric)
        metric.account = self._account
        self._metrics[metric.name] = metric

    def backtest(self) -> None:
        assert self._strategy is not None, 'Need to set the Strategy Object!'

        self._account.reset()
        for metric in self._metrics.values():
            metric._reset()

        with tqdm(self._account.exchange.time_line, desc='Tidal Backtesting') as progress:
            self._state = State.INIT
            self._strategy._on_init()
            self._state = State.BACKTEST

            for datetime in progress:
                self._update_trade_report = True

                for metric in self._metrics.values():
                    metric._evaluate()

                self._strategy._on_trade()

                progress.set_postfix(cash=self._account.cash, position_cost=self._account.position_cost,
                                     pnl=self._account.pnl, value=self._account.value)
                self._account.step()

        self._state = State.IDLE

    async def async_backtest(self, on_progress: Callable) -> None:

        assert self._strategy is not None, 'Need to set the Strategy Object!'

        self._account.reset()
        for metric in self._metrics.values():
            metric._reset()

        with tqdm(self._account.exchange.time_line, desc='Tidal Backtesting') as progress:
            self._state = State.INIT
            if callable(on_progress):
                await on_progress(None, self)

            self._strategy._on_init()
            self._state = State.BACKTEST

            for datetime in progress:
                for metric in self._metrics.values():
                    metric._evaluate()

                self._strategy._on_trade()

                progress.set_postfix(cash=self._account.cash, position_cost=self._account.position_cost,
                                     pnl=self._account.pnl, value=self._account.value)

                if callable(on_progress):
                    await on_progress(progress, self)

                self._account.step()

        self._state = State.IDLE
        if callable(on_progress):
            await on_progress(progress, self)

    def tdboard(self, port: int = 0) -> None:
        app = create_app(self)
        app.run(port=port, use_reloader=False, threaded=False)
